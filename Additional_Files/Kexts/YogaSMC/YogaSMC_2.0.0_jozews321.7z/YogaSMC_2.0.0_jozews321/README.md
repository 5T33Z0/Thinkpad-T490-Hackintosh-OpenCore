# About

YogaSMC build based on Fork from jozews312 for macOS Tahoe compatibility:

[https://github.com/jozews321/YogaSMC](https://github.com/jozews321/YogaSMC)
